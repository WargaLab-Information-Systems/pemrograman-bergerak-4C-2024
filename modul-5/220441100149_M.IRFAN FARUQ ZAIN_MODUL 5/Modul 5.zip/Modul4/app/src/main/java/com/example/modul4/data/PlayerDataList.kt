package com.example.modul4.data

import com.example.modul4.R

object PlayerDataList {

    val playerDataValue = arrayListOf(
        PlayerData(
            "Kevin De Bruyne",
            R.drawable.arneslot
        ),
        PlayerData(
            "Kevin De Bruyne",
            R.drawable.arneslot
        ),
        PlayerData(
            "Kevin De Bruyne",
            R.drawable.arneslot
        ),
    )
}