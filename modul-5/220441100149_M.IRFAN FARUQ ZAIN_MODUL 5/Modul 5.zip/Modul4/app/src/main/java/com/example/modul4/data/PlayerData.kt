package com.example.modul4.data


data class PlayerData (
    val name: String,
    val image: Int
)