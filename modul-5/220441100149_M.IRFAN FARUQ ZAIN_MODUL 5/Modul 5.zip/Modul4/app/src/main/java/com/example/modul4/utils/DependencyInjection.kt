package com.example.modul4.utils

import android.content.Context
import com.example.modul4.room.PlayerDatabase
import com.example.modul4.room.PlayerRepository

object DependencyInjection {
    // Menyediakan instance dari AppRepository
    fun provideRepository(context: Context): PlayerRepository {
        // Membuat instance dari AppDatabase
        val database = PlayerDatabase.getDatabase(context)
        // Membuat instance dari AppExecutors
        val appExecutors = AppExecutors()
        // Mendapatkan instance dari AppDao dari AppDatabase
        val dao = database.playerDao()
        // Mendapatkan instance dari AppRepository menggunakan AppDao dan AppExecutors
        return PlayerRepository.getInstance(dao, appExecutors)
    }
}