package com.example.modul4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ConcatAdapter
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.modul4.adapter.PlayerAdapter
import com.example.modul4.room.PlayerEntity
import com.example.modul4.room.PlayerViewModel
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.textview.MaterialTextView

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        // Mengambil data dari intent yang terdapat di dalam activity Room
        val getDataPlayer = intent.getParcelableExtra<PlayerEntity>("player")

        // Menghubungkan variabel dengan komponen di layout
        val playerName = findViewById<TextView>(R.id.text_player)
        val playerImage = findViewById<ImageView>(R.id.image_player)

        playerName.text = getDataPlayer!!.name
        Glide.with(playerImage)
            .load(getDataPlayer.image)
            .into(playerImage)
    }
}