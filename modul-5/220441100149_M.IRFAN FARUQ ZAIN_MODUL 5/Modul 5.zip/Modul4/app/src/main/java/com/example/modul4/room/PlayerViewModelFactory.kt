package com.example.modul4.room

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.modul4.utils.DependencyInjection

class PlayerViewModelFactory private constructor(private val playerRepository: PlayerRepository) :
    ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PlayerViewModel::class.java)) {
            return PlayerViewModel(playerRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }

    companion object {
        @Volatile
        private var instance: PlayerViewModelFactory? = null
        fun getInstance(context: Context): PlayerViewModelFactory =
            instance ?: synchronized(this) {
                instance ?: PlayerViewModelFactory(DependencyInjection.provideRepository(context))
            }.also { instance = it }
    }
}