package com.example.modul4.room

import androidx.lifecycle.LiveData
import com.example.modul4.utils.AppExecutors

class PlayerRepository private constructor(private val playerDao: PlayerDao, private val appExecutors: AppExecutors) {

    // Mendapatkan semua data pemain dari database
    fun getAllPlayer(): LiveData<List<PlayerEntity>> = playerDao.getAllPlayer()

    // Memasukkan data pemain ke dalam database
    fun insertPlayer(player: PlayerEntity) {
        // Menjalankan operasi insert di thread yang berbeda
        appExecutors.diskIO().execute { playerDao.insertPlayer(player) }
    }

    companion object {
        // Variabel untuk menyimpan instance dari AppRepository
        @Volatile
        private var instance: PlayerRepository? = null

        // Mendapatkan instance dari AppRepository
        fun getInstance(
            appDao: PlayerDao,
            appExecutors: AppExecutors
        ): PlayerRepository =
            // Jika instance null, maka akan dibuat instance baru
            instance ?: synchronized(this) {
                instance ?: PlayerRepository(appDao, appExecutors)
            }.also { instance = it }
    }
}