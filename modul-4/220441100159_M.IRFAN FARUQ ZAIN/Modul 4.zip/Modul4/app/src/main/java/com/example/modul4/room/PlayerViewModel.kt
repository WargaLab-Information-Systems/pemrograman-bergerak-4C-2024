package com.example.modul4.room

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel

class PlayerViewModel(private val playerRepository: PlayerRepository) : ViewModel() {

    // Memasukkan data pemain ke dalam database
    fun insertPlayer(playerEntity: PlayerEntity) {
        playerRepository.insertPlayer(playerEntity)
    }

    // Mendapatkan semua data pemain dari database
    fun getAllPlayer(): LiveData<List<PlayerEntity>> {
        return playerRepository.getAllPlayer()
    }
}